DenteBlu — Bluetooth Stack for Haiku (x86_64)
===============================================

Supported profiles:
  - SPP   (Serial Port Profile) — serial communication via RFCOMM
  - PBAP  (Phone Book Access) — download contacts from phone
  - OPP   (Object Push Profile) — send files to phone
  - HFP   (Hands-Free Profile) — AT commands, SCO audio
  - A2DP  (Advanced Audio, Sink) — stereo audio reception
  - BLE   (GATT/ATT/SMP) — scan and pair BLE devices

Requirements:
  - Haiku x86_64 (beta5 or nightly)
  - USB Bluetooth dongle (Broadcom, Intel, etc.)
  - For Intel controllers: .sfi firmware in the appropriate directory

Package contents:
  servers/bluetooth_server    — Bluetooth server
  lib/libbluetooth.so         — Bluetooth kit library
  kernel/bluetooth/btCoreData — kernel module for connection data
  kernel/bluetooth/hci        — HCI kernel module
  kernel/network/protocols/l2cap — L2CAP kernel protocol
  kernel/drivers/bluetooth/h2/h2generic — USB BT driver
  preferences/Bluetooth       — Bluetooth preferences panel
  bin/BluetoothSendFile       — standalone file send app (OPP)
  add-ons/BluetoothDeskbarReplicant — Deskbar tray icon
  tests/bt_intel_test         — Intel TLV parsing tests
  install.sh                  — installation script
  README.txt                  — this file

Installation:
  1. Extract the zip to a directory
  2. Open a Terminal
  3. cd into the extracted directory
  4. sh install.sh
  5. Reboot the system

Main changes in this release (r005):
  - BluetoothSendFile: standalone app for sending files via OPP
  - Deskbar icon: right-click for "Send file...", "Settings...", "Quit"
  - Deskbar replicant is now a lightweight add-on (no libbluetooth
    dependency — fixes icon not showing on some systems)
  - btintel: fire-and-forget for Secure Send (fixes AX201/AX211)
  - install.sh: pre-flight checks, backup, verification, --check mode

After reboot:
  - Bluetooth icon appears in the Deskbar tray (bottom right)
  - Right-click the icon for: Send file, Settings, Quit
  - Open "Preferences > Bluetooth" to see and manage devices
  - Server log: /tmp/bt_server.log
  - Kernel log (L2CAP): grep "bt:" /var/log/syslog

Intel firmware:
  Intel USB controllers start in "bootloader mode" and need a .sfi
  firmware file to become operational.

  1. Identify the required firmware:
     - Plug in the dongle and reboot
     - Look in /tmp/bt_server.log for:
       "btintel: firmware file 'ibt-XXXX-YYYY.sfi' not found"
  2. Download the file from:
     https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/tree/intel/
  3. Copy to:
     /boot/system/non-packaged/data/firmware/intel/
  4. Reboot
